/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 09_disparadores.sql · Entrega final
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Disparadores de auditoría, de validación y de mantenimiento
   ========================================================================== */

-- Se desarrolla para la Entrega final.
-- El enunciado de esa entrega fija los requisitos detallados.
