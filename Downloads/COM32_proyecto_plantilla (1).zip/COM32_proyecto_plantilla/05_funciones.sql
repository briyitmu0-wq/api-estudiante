/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 05_funciones.sql · Entrega E2
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Al menos 2 funciones invocables desde SQL
   ========================================================================== */

-- Se desarrolla para la Entrega 2.
-- El enunciado de esa entrega fija los requisitos detallados.
