/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 03_validaciones.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Bloques anónimos de validación, uno por regla de negocio (R01, R02…)
   ========================================================================== */

SET SERVEROUTPUT ON;

-- Un bloque por regla. Encima de cada bloque, tres líneas:
-- R0n · <regla del negocio en una frase>
-- Tablas: <tablas que lee o modifica>
-- Resultado esperado con 02_datos.sql: <valor exacto que muestra el bloque>

-- R01 · <regla>
-- Tablas: <tabla>
-- Resultado esperado con 02_datos.sql: <valor>
DECLARE
  v_total PLS_INTEGER;
BEGIN
  SELECT COUNT(*) INTO v_total FROM <tabla>;
  DBMS_OUTPUT.PUT_LINE('R01 · ' || v_total);
END;
/
