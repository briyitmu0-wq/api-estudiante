/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 07_permisos.sql · Entrega E2
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Usuarios, roles, GRANT y REVOKE en Supabase, con la sintaxis Oracle al lado
   ========================================================================== */

-- Se desarrolla para la Entrega 2.
-- El enunciado de esa entrega fija los requisitos detallados.
