/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 06_cursores.sql · Entrega E2
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Un cursor explícito y un cursor FOR que producen un reporte
   ========================================================================== */

-- Se desarrolla para la Entrega 2.
-- El enunciado de esa entrega fija los requisitos detallados.
