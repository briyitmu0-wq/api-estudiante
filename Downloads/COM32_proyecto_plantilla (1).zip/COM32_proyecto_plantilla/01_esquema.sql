/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 01_esquema.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: CREATE TABLE con PK, FK, NOT NULL, UNIQUE, CHECK y DEFAULT, en orden ejecutable
   ========================================================================== */

-- Una sección por tabla, en orden de dependencia: primero las que no tienen FK.
-- Nombres de restricción: pk_<tabla>, fk_<hija>_<padre>, uq_<tabla>_<col>, ck_<tabla>_<col>.

-- <tabla_padre> · <qué guarda, en una frase>
CREATE TABLE <tabla_padre> (
  <id>     NUMBER(6)    CONSTRAINT pk_<tabla_padre> PRIMARY KEY,
  <nombre> VARCHAR2(60) NOT NULL,
  <estado> VARCHAR2(10) DEFAULT 'ACTIVO' NOT NULL
           CONSTRAINT ck_<tabla_padre>_estado CHECK (<estado> IN ('ACTIVO', 'INACTIVO'))
);

-- <tabla_hija> · <qué guarda>
CREATE TABLE <tabla_hija> (
  <id>       NUMBER(6) CONSTRAINT pk_<tabla_hija> PRIMARY KEY,
  <id_padre> NUMBER(6) NOT NULL
             CONSTRAINT fk_<tabla_hija>_<tabla_padre> REFERENCES <tabla_padre> (<id>)
);
