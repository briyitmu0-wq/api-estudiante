/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 10_pruebas.sql · Entrega final
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Pruebas de todo el sistema, incluido el rechazo del disparador de validación
   ========================================================================== */

-- Se desarrolla para la Entrega final.
-- El enunciado de esa entrega fija los requisitos detallados.
