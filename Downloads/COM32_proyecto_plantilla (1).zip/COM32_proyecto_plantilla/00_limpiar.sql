/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 00_limpiar.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: DROP de todos los objetos del proyecto, en orden inverso de dependencia
   ========================================================================== */

-- Elimina los objetos del proyecto para ejecutar todo desde un esquema limpio.
-- Orden inverso al de creación: primero las tablas hijas (con FK), después las padres.
-- La primera vez, las tablas no existen y APEX informa el error ORA-00942: se ignora.
-- DROP TABLE <tabla_hija>  PURGE;
-- DROP TABLE <tabla_padre> PURGE;
