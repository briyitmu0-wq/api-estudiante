/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 08_paquete.sql · Entrega final
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: CREATE PACKAGE y PACKAGE BODY: público, privado y una sobrecarga
   ========================================================================== */

-- Se desarrolla para la Entrega final.
-- El enunciado de esa entrega fija los requisitos detallados.
