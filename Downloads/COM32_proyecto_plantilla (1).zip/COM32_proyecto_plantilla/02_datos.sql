/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 02_datos.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: INSERT con mínimo 15 filas por tabla, casos límite incluidos, y COMMIT
   ========================================================================== */

-- Mínimo 15 filas por tabla, con datos verosímiles del negocio. Fechas fijas
-- (DATE '2026-10-01'), nunca SYSDATE: los resultados esperados de 03 dependen de ellas.
-- Incluya los casos límite que necesitan las reglas de 03 (existencias en 0, fecha
-- vencida, cupo lleno…) y márquelos con un comentario.

-- <tabla_padre> (15 filas)
INSERT INTO <tabla_padre> (<id>, <nombre>) VALUES (1, '<dato real>');

COMMIT;
