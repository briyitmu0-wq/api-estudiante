/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · <negocio en una frase>
   Script: 04_procedimientos.sql · Entrega E2
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · …
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Al menos 4 procedimientos con parámetros IN, OUT o IN OUT
   ========================================================================== */

-- Se desarrolla para la Entrega 2.
-- El enunciado de esa entrega fija los requisitos detallados.
