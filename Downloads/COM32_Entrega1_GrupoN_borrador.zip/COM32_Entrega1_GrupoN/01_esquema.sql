/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · Cafetería con pedidos digitales por código QR
   Script: 01_esquema.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · <Apellido Nombre>
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: CREATE TABLE con PK, FK, NOT NULL, UNIQUE, CHECK y DEFAULT, en orden ejecutable
   ========================================================================== */

-- Una sección por tabla, en orden de dependencia: primero las que no tienen FK.
-- Nombres de restricción: pk_<tabla>, fk_<hija>_<padre>, uq_<tabla>_<col>, ck_<tabla>_<col>.
-- Relaciones: categoria 1:N producto · mesa 1:N pedido · producto N:M ingrediente (tabla receta)
--             pedido 1:N detalle_pedido (entidad débil, PK compuesta id_pedido + linea).

-- categoria · grupos del menú (cafés calientes, jugos, panadería…)
CREATE TABLE categoria (
  id_categoria NUMBER(6)    CONSTRAINT pk_categoria PRIMARY KEY,
  nombre       VARCHAR2(40) NOT NULL
               CONSTRAINT uq_categoria_nombre UNIQUE,
  estado       VARCHAR2(10) DEFAULT 'ACTIVO' NOT NULL
               CONSTRAINT ck_categoria_estado CHECK (estado IN ('ACTIVO', 'INACTIVO'))
);

-- producto · artículo del menú que el cliente pide al escanear el QR; precio en pesos colombianos
CREATE TABLE producto (
  id_producto  NUMBER(6)    CONSTRAINT pk_producto PRIMARY KEY,
  id_categoria NUMBER(6)    NOT NULL
               CONSTRAINT fk_producto_categoria REFERENCES categoria (id_categoria),
  nombre       VARCHAR2(60) NOT NULL
               CONSTRAINT uq_producto_nombre UNIQUE,
  precio       NUMBER(8)    NOT NULL
               CONSTRAINT ck_producto_precio CHECK (precio > 0),
  existencias  NUMBER(5)    DEFAULT 0 NOT NULL
               CONSTRAINT ck_producto_existencias CHECK (existencias >= 0),
  estado       VARCHAR2(12) DEFAULT 'DISPONIBLE' NOT NULL
               CONSTRAINT ck_producto_estado CHECK (estado IN ('DISPONIBLE', 'AGOTADO', 'INACTIVO'))
);

-- ingrediente · materia prima de cocina con su stock y su mínimo de reposición
CREATE TABLE ingrediente (
  id_ingrediente NUMBER(6)    CONSTRAINT pk_ingrediente PRIMARY KEY,
  nombre         VARCHAR2(40) NOT NULL
                 CONSTRAINT uq_ingrediente_nombre UNIQUE,
  unidad         VARCHAR2(5)  NOT NULL
                 CONSTRAINT ck_ingrediente_unidad CHECK (unidad IN ('KG', 'LT', 'UND')),
  stock_actual   NUMBER(8,2)  DEFAULT 0 NOT NULL
                 CONSTRAINT ck_ingrediente_stock_actual CHECK (stock_actual >= 0),
  stock_minimo   NUMBER(8,2)  DEFAULT 0 NOT NULL
                 CONSTRAINT ck_ingrediente_stock_minimo CHECK (stock_minimo >= 0)
);

-- receta · tabla intermedia de la relación N:M producto-ingrediente: cuánto lleva cada producto
CREATE TABLE receta (
  id_producto    NUMBER(6)   NOT NULL
                 CONSTRAINT fk_receta_producto REFERENCES producto (id_producto),
  id_ingrediente NUMBER(6)   NOT NULL
                 CONSTRAINT fk_receta_ingrediente REFERENCES ingrediente (id_ingrediente),
  cantidad       NUMBER(8,3) NOT NULL
                 CONSTRAINT ck_receta_cantidad CHECK (cantidad > 0),
  CONSTRAINT pk_receta PRIMARY KEY (id_producto, id_ingrediente)
);

-- mesa · mesa física del local; su código QR identifica desde dónde llega el pedido
CREATE TABLE mesa (
  id_mesa   NUMBER(6)    CONSTRAINT pk_mesa PRIMARY KEY,
  zona      VARCHAR2(10) NOT NULL
            CONSTRAINT ck_mesa_zona CHECK (zona IN ('SALON', 'TERRAZA', 'BARRA')),
  capacidad NUMBER(2)    NOT NULL
            CONSTRAINT ck_mesa_capacidad CHECK (capacidad BETWEEN 1 AND 12),
  codigo_qr VARCHAR2(20) NOT NULL
            CONSTRAINT uq_mesa_codigo_qr UNIQUE,
  estado    VARCHAR2(10) DEFAULT 'LIBRE' NOT NULL
            CONSTRAINT ck_mesa_estado CHECK (estado IN ('LIBRE', 'OCUPADA', 'INACTIVA'))
);

-- pedido · cabecera del pedido hecho desde una mesa
CREATE TABLE pedido (
  id_pedido     NUMBER(6)    CONSTRAINT pk_pedido PRIMARY KEY,
  id_mesa       NUMBER(6)    NOT NULL
                CONSTRAINT fk_pedido_mesa REFERENCES mesa (id_mesa),
  fecha_hora    DATE         NOT NULL,
  estado        VARCHAR2(15) DEFAULT 'ABIERTO' NOT NULL
                CONSTRAINT ck_pedido_estado CHECK (estado IN
                  ('ABIERTO', 'EN_PREPARACION', 'ENTREGADO', 'PAGADO', 'CANCELADO')),
  observaciones VARCHAR2(100)
);

-- detalle_pedido · entidad débil: una línea no existe sin su pedido, PK compuesta (id_pedido, linea)
CREATE TABLE detalle_pedido (
  id_pedido       NUMBER(6) NOT NULL
                  CONSTRAINT fk_detalle_pedido_pedido REFERENCES pedido (id_pedido)
                  ON DELETE CASCADE,
  linea           NUMBER(3) NOT NULL
                  CONSTRAINT ck_detalle_pedido_linea CHECK (linea > 0),
  id_producto     NUMBER(6) NOT NULL
                  CONSTRAINT fk_detalle_pedido_producto REFERENCES producto (id_producto),
  cantidad        NUMBER(2) DEFAULT 1 NOT NULL
                  CONSTRAINT ck_detalle_pedido_cantidad CHECK (cantidad BETWEEN 1 AND 10),
  precio_unitario NUMBER(8) NOT NULL
                  CONSTRAINT ck_detalle_pedido_precio CHECK (precio_unitario > 0),
  CONSTRAINT pk_detalle_pedido PRIMARY KEY (id_pedido, linea)
);
