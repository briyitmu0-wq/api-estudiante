/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · Cafetería con pedidos digitales por código QR
   Script: 02_datos.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · <Apellido Nombre>
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: INSERT con mínimo 15 filas por tabla, casos límite incluidos, y COMMIT
   ========================================================================== */

-- Fechas fijas (TO_DATE con valores literales), nunca SYSDATE: los resultados esperados
-- de 03_validaciones.sql dependen de estos datos. Precios en pesos colombianos.
-- Los casos límite están marcados con el comentario «LÍMITE».


-- categoria (15 filas)

INSERT INTO categoria (id_categoria, nombre) VALUES (1, 'Cafés calientes');
INSERT INTO categoria (id_categoria, nombre) VALUES (2, 'Cafés fríos');
INSERT INTO categoria (id_categoria, nombre) VALUES (3, 'Infusiones y té');
INSERT INTO categoria (id_categoria, nombre) VALUES (4, 'Chocolates');
INSERT INTO categoria (id_categoria, nombre) VALUES (5, 'Jugos naturales');
INSERT INTO categoria (id_categoria, nombre) VALUES (6, 'Limonadas');
INSERT INTO categoria (id_categoria, nombre) VALUES (7, 'Batidos');
INSERT INTO categoria (id_categoria, nombre) VALUES (8, 'Panadería');
INSERT INTO categoria (id_categoria, nombre) VALUES (9, 'Pasteles y tortas');
INSERT INTO categoria (id_categoria, nombre) VALUES (10, 'Sándwiches');
INSERT INTO categoria (id_categoria, nombre) VALUES (11, 'Fritos típicos');
INSERT INTO categoria (id_categoria, nombre) VALUES (12, 'Desayunos');
INSERT INTO categoria (id_categoria, nombre) VALUES (13, 'Postres');
INSERT INTO categoria (id_categoria, nombre) VALUES (14, 'Helados');
INSERT INTO categoria (id_categoria, nombre) VALUES (15, 'Bebidas embotelladas');

-- producto (25 filas)

INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (1, 1, 'Tinto pequeño', 2500, 100, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (2, 1, 'Americano', 3500, 80, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (3, 1, 'Capuchino', 5500, 60, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (4, 1, 'Latte', 6000, 60, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (5, 1, 'Moka', 6500, 50, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (6, 2, 'Café helado', 6500, 40, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (7, 2, 'Frappé de café', 8500, 30, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (8, 3, 'Té chai', 5000, 35, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (9, 3, 'Aromática de menta', 3000, 50, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (10, 4, 'Chocolate caliente', 5000, 45, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (11, 5, 'Jugo de lulo', 6000, 25, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (12, 5, 'Jugo de maracuyá', 6000, 0, 'AGOTADO'); -- LÍMITE: existencias en 0, producto AGOTADO
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (13, 6, 'Limonada de coco', 7500, 30, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (14, 7, 'Batido de mango', 7500, 20, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (15, 8, 'Pandebono', 2500, 40, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (16, 8, 'Croissant de queso', 4500, 12, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (17, 9, 'Torta de zanahoria (porción)', 7000, 8, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (18, 9, 'Brownie', 5500, 0, 'AGOTADO'); -- LÍMITE: existencias en 0, producto AGOTADO
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (19, 10, 'Sándwich de pollo', 12000, 15, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (20, 11, 'Empanada de carne', 3000, 50, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (21, 11, 'Carimañola', 3500, 40, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (22, 12, 'Desayuno costeño', 14000, 20, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (23, 13, 'Flan de caramelo', 6000, 3, 'DISPONIBLE'); -- LÍMITE: existencias por debajo del umbral de 5
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (24, 14, 'Helado de vainilla', 5000, 18, 'DISPONIBLE');
INSERT INTO producto (id_producto, id_categoria, nombre, precio, existencias, estado) VALUES (25, 15, 'Agua mineral', 3000, 60, 'DISPONIBLE');

-- ingrediente (20 filas)

INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (1, 'Café en grano', 'KG', 12.5, 5);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (2, 'Leche entera', 'LT', 40, 15);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (3, 'Azúcar', 'KG', 20, 8);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (4, 'Cacao en polvo', 'KG', 3, 2);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (5, 'Pulpa de lulo', 'KG', 6, 4);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (6, 'Pulpa de maracuyá', 'KG', 0, 4); -- LÍMITE: stock en 0
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (7, 'Crema de coco', 'LT', 8, 3);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (8, 'Limones', 'KG', 10, 4);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (9, 'Mango', 'KG', 7, 3);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (10, 'Harina de trigo', 'KG', 25, 10);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (11, 'Queso costeño', 'KG', 4, 4); -- LÍMITE: stock igual al mínimo
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (12, 'Huevos', 'UND', 90, 60);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (13, 'Pechuga de pollo', 'KG', 5, 3);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (14, 'Pan de molde', 'UND', 30, 12);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (15, 'Harina de maíz', 'KG', 14, 6);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (16, 'Carne molida', 'KG', 3.5, 4); -- LÍMITE: stock por debajo del mínimo
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (17, 'Base de helado de vainilla', 'LT', 9, 4);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (18, 'Zanahoria', 'KG', 6, 2);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (19, 'Hojas de menta', 'KG', 0.5, 0.3);
INSERT INTO ingrediente (id_ingrediente, nombre, unidad, stock_actual, stock_minimo) VALUES (20, 'Mezcla de té chai', 'KG', 1.2, 0.5);

-- receta (26 filas) · N:M producto-ingrediente; cantidad por unidad de producto

INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (1, 1, 0.012);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (2, 1, 0.018);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (3, 1, 0.018);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (3, 2, 0.15);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (4, 1, 0.018);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (4, 2, 0.25);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (5, 1, 0.018);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (5, 2, 0.2);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (5, 4, 0.015);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (6, 1, 0.018);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (6, 2, 0.1);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (6, 3, 0.015);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (10, 4, 0.025);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (10, 2, 0.2);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (13, 8, 0.2);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (13, 7, 0.1);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (13, 3, 0.02);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (15, 15, 0.05);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (15, 11, 0.03);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (15, 12, 0.25);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (20, 15, 0.06);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (20, 16, 0.05);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (21, 16, 0.05);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (21, 11, 0.03);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (21, 15, 0.04);
INSERT INTO receta (id_producto, id_ingrediente, cantidad) VALUES (24, 17, 0.12);

-- mesa (16 filas) · código QR único por mesa

INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (1, 'SALON', 4, 'QRC-M01-4F7A', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (2, 'SALON', 4, 'QRC-M02-9B21', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (3, 'SALON', 2, 'QRC-M03-C3D8', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (4, 'SALON', 6, 'QRC-M04-17E5', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (5, 'SALON', 4, 'QRC-M05-A60F', 'OCUPADA');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (6, 'SALON', 4, 'QRC-M06-52BC', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (7, 'SALON', 6, 'QRC-M07-E94D', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (8, 'SALON', 2, 'QRC-M08-3A8E', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (9, 'TERRAZA', 4, 'QRC-M09-7D15', 'OCUPADA');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (10, 'TERRAZA', 4, 'QRC-M10-B2F6', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (11, 'TERRAZA', 2, 'QRC-M11-6C49', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (12, 'TERRAZA', 6, 'QRC-M12-D07A', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (13, 'TERRAZA', 4, 'QRC-M13-18E3', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (14, 'BARRA', 2, 'QRC-M14-F5B9', 'OCUPADA');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (15, 'BARRA', 2, 'QRC-M15-2C64', 'LIBRE');
INSERT INTO mesa (id_mesa, zona, capacidad, codigo_qr, estado) VALUES (16, 'BARRA', 1, 'QRC-M16-8A0D', 'INACTIVA'); -- LÍMITE: mesa fuera de servicio

-- pedido (20 filas) · 12 y 13 de octubre de 2026

INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1001, 1, TO_DATE('2026-10-12 08:05', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1002, 2, TO_DATE('2026-10-12 08:20', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1003, 3, TO_DATE('2026-10-12 08:45', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1004, 9, TO_DATE('2026-10-12 09:10', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1005, 4, TO_DATE('2026-10-12 09:30', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1006, 14, TO_DATE('2026-10-12 10:00', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1007, 5, TO_DATE('2026-10-12 10:25', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1008, 10, TO_DATE('2026-10-12 11:00', 'YYYY-MM-DD HH24:MI'), 'CANCELADO'); -- LÍMITE: pedido cancelado
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1009, 6, TO_DATE('2026-10-12 11:40', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1010, 11, TO_DATE('2026-10-12 12:15', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1011, 7, TO_DATE('2026-10-12 12:50', 'YYYY-MM-DD HH24:MI'), 'PAGADO'); -- LÍMITE: línea de 10 unidades
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1012, 1, TO_DATE('2026-10-12 14:05', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1013, 12, TO_DATE('2026-10-12 15:20', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1014, 15, TO_DATE('2026-10-12 16:10', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1015, 8, TO_DATE('2026-10-12 16:45', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1016, 3, TO_DATE('2026-10-13 07:55', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1017, 13, TO_DATE('2026-10-13 08:30', 'YYYY-MM-DD HH24:MI'), 'PAGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1018, 5, TO_DATE('2026-10-13 09:05', 'YYYY-MM-DD HH24:MI'), 'ENTREGADO');
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1019, 9, TO_DATE('2026-10-13 09:20', 'YYYY-MM-DD HH24:MI'), 'EN_PREPARACION'); -- pedido activo
INSERT INTO pedido (id_pedido, id_mesa, fecha_hora, estado) VALUES (1020, 14, TO_DATE('2026-10-13 09:35', 'YYYY-MM-DD HH24:MI'), 'ABIERTO'); -- pedido activo

-- detalle_pedido (43 filas) · entidad débil, PK (id_pedido, linea); precio_unitario = precio vigente al pedir

INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1001, 1, 3, 2, 5500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1001, 2, 15, 2, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1002, 1, 1, 1, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1002, 2, 20, 1, 3000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1003, 1, 2, 2, 3500); -- pedido 1003: total esperado en R02 = 37500
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1003, 2, 22, 2, 14000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1003, 3, 15, 1, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1004, 1, 13, 2, 7500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1004, 2, 19, 1, 12000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1005, 1, 4, 1, 6000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1005, 2, 16, 1, 4500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1005, 3, 10, 1, 5000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1006, 1, 2, 1, 3500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1007, 1, 6, 2, 6500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1007, 2, 17, 2, 7000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1008, 1, 7, 1, 8500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1009, 1, 1, 3, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1009, 2, 21, 3, 3500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1010, 1, 11, 1, 6000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1010, 2, 19, 1, 12000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1010, 3, 24, 1, 5000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1011, 1, 20, 10, 3000); -- LÍMITE: cantidad en el tope de 10
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1011, 2, 1, 8, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1011, 3, 21, 6, 3500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1012, 1, 3, 1, 5500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1012, 2, 23, 1, 6000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1013, 1, 14, 2, 7500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1013, 2, 25, 2, 3000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1014, 1, 5, 1, 6500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1014, 2, 18, 1, 5500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1015, 1, 12, 2, 6000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1015, 2, 15, 4, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1016, 1, 22, 1, 14000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1016, 2, 3, 1, 5500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1017, 1, 8, 2, 5000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1017, 2, 16, 2, 4500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1018, 1, 19, 2, 12000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1018, 2, 13, 2, 7500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1018, 3, 24, 1, 5000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1019, 1, 3, 1, 5500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1019, 2, 9, 1, 3000);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1020, 1, 1, 1, 2500);
INSERT INTO detalle_pedido (id_pedido, linea, id_producto, cantidad, precio_unitario) VALUES (1020, 2, 20, 2, 3000);

COMMIT;
