/* ============================================================================
   COM32 · Proyecto integrador · Grupo N · Cafetería con pedidos digitales por código QR
   Script: 03_validaciones.sql · Entrega E1
   Integrantes: <Apellido Nombre> · <Apellido Nombre> · <Apellido Nombre>
   Entorno: Oracle APEX (apex.oracle.com), SQL Workshop > SQL Scripts
   Contenido: Bloques anónimos de validación, uno por regla de negocio (R01, R02…)
   ========================================================================== */

SET SERVEROUTPUT ON;

-- R01 · Un producto con existencias en 0 está AGOTADO y no se ofrece en el menú QR.
-- Tablas: producto
-- Resultado esperado con 02_datos.sql: R01 · agotados=2 · inconsistentes=0 · menor existencia=Flan de caramelo
DECLARE
  c_umbral         CONSTANT producto.existencias%TYPE := 5;
  v_agotados       PLS_INTEGER;
  v_inconsistentes PLS_INTEGER;
  v_critico        producto.nombre%TYPE;
BEGIN
  SELECT COUNT(*) INTO v_agotados
    FROM producto WHERE existencias = 0 AND estado = 'AGOTADO';
  SELECT COUNT(*) INTO v_inconsistentes
    FROM producto
   WHERE (existencias = 0 AND estado <> 'AGOTADO')
      OR (existencias > 0 AND estado = 'AGOTADO');
  SELECT nombre INTO v_critico
    FROM producto
   WHERE existencias > 0 AND existencias < c_umbral;
  DBMS_OUTPUT.PUT_LINE('R01 · agotados=' || v_agotados ||
                       ' · inconsistentes=' || v_inconsistentes ||
                       ' · menor existencia=' || v_critico);
END;
/

-- R02 · El valor de un pedido es la suma de cantidad × precio_unitario de sus líneas.
-- Tablas: pedido, detalle_pedido
-- Resultado esperado con 02_datos.sql: R02 · pedido 1003 · estado=PAGADO · líneas=3 · total=37500
DECLARE
  c_pedido   CONSTANT pedido.id_pedido%TYPE := 1003;
  v_estado   pedido.estado%TYPE;
  v_lineas   PLS_INTEGER;
  v_valor    NUMBER;
BEGIN
  SELECT estado INTO v_estado FROM pedido WHERE id_pedido = c_pedido;
  SELECT COUNT(*), SUM(cantidad * precio_unitario) INTO v_lineas, v_valor
    FROM detalle_pedido WHERE id_pedido = c_pedido;
  DBMS_OUTPUT.PUT_LINE('R02 · pedido ' || c_pedido || ' · estado=' || v_estado ||
                       ' · líneas=' || v_lineas || ' · total=' || v_valor);
END;
/

-- R03 · Cada mesa tiene un código QR único, que identifica desde dónde llega el pedido.
-- Tablas: mesa
-- Resultado esperado con 02_datos.sql: R03 · mesas=16 · códigos distintos=16 · mesa 7=QRC-M07-E94D
DECLARE
  c_mesa      CONSTANT mesa.id_mesa%TYPE := 7;
  v_mesas     PLS_INTEGER;
  v_codigos   PLS_INTEGER;
  v_qr_mesa   mesa.codigo_qr%TYPE;
BEGIN
  SELECT COUNT(*), COUNT(DISTINCT codigo_qr) INTO v_mesas, v_codigos FROM mesa;
  SELECT codigo_qr INTO v_qr_mesa FROM mesa WHERE id_mesa = c_mesa;
  DBMS_OUTPUT.PUT_LINE('R03 · mesas=' || v_mesas || ' · códigos distintos=' || v_codigos ||
                       ' · mesa ' || c_mesa || '=' || v_qr_mesa);
END;
/

-- R04 · Una línea de pedido no puede pedir más de 10 unidades de un mismo producto.
-- Tablas: detalle_pedido
-- Resultado esperado con 02_datos.sql: R04 · cantidad máxima=10 · líneas sobre el tope=0
DECLARE
  c_max_cantidad CONSTANT detalle_pedido.cantidad%TYPE := 10;
  v_maximo       detalle_pedido.cantidad%TYPE;
  v_excedidas    PLS_INTEGER;
BEGIN
  SELECT MAX(cantidad) INTO v_maximo FROM detalle_pedido;
  SELECT COUNT(*) INTO v_excedidas
    FROM detalle_pedido WHERE cantidad > c_max_cantidad;
  DBMS_OUTPUT.PUT_LINE('R04 · cantidad máxima=' || v_maximo ||
                       ' · líneas sobre el tope=' || v_excedidas);
END;
/

-- R05 · Un ingrediente con stock igual o menor al mínimo debe reponerse.
-- Tablas: ingrediente
-- Resultado esperado con 02_datos.sql: R05 · por reponer=3 · sin stock=1 · agotado=Pulpa de maracuyá
DECLARE
  v_por_reponer PLS_INTEGER;
  v_sin_stock   PLS_INTEGER;
  v_agotado     ingrediente.nombre%TYPE;
BEGIN
  SELECT COUNT(*) INTO v_por_reponer
    FROM ingrediente WHERE stock_actual <= stock_minimo;
  SELECT COUNT(*) INTO v_sin_stock
    FROM ingrediente WHERE stock_actual = 0;
  SELECT nombre INTO v_agotado
    FROM ingrediente WHERE stock_actual = 0;
  DBMS_OUTPUT.PUT_LINE('R05 · por reponer=' || v_por_reponer ||
                       ' · sin stock=' || v_sin_stock ||
                       ' · agotado=' || v_agotado);
END;
/

-- R06 · Una mesa no puede tener más de un pedido activo (ABIERTO o EN_PREPARACION) a la vez.
-- Tablas: pedido
-- Resultado esperado con 02_datos.sql: R06 · pedidos activos=2 · mesas con más de 1 activo=0 · pedido 1019 en mesa 9
DECLARE
  c_max_activos CONSTANT PLS_INTEGER := 1;
  c_pedido      CONSTANT pedido.id_pedido%TYPE := 1019;
  v_activos     PLS_INTEGER;
  v_excedidas   PLS_INTEGER;
  v_mesa        pedido.id_mesa%TYPE;
BEGIN
  SELECT COUNT(*) INTO v_activos
    FROM pedido WHERE estado IN ('ABIERTO', 'EN_PREPARACION');
  SELECT COUNT(*) INTO v_excedidas
    FROM (SELECT id_mesa FROM pedido
           WHERE estado IN ('ABIERTO', 'EN_PREPARACION')
           GROUP BY id_mesa
          HAVING COUNT(*) > c_max_activos);
  SELECT id_mesa INTO v_mesa FROM pedido WHERE id_pedido = c_pedido;
  DBMS_OUTPUT.PUT_LINE('R06 · pedidos activos=' || v_activos ||
                       ' · mesas con más de 1 activo=' || v_excedidas ||
                       ' · pedido ' || c_pedido || ' en mesa ' || v_mesa);
END;
/
